export default {
  extends: ["next/core-web-vitals"],

  rules: {
    "no-console": "warn"
  }
}
